(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/loom.contentScript.ts.50b01852.js")
    );
  })().catch(console.error);

})();

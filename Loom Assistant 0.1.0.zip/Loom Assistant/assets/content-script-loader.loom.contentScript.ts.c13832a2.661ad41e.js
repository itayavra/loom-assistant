(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/loom.contentScript.ts.c13832a2.js")
    );
  })().catch(console.error);

})();
